(function($){$(function(){$(".jqMasonry").not(".jqInited").each(function(){var $this=$(this);$this.addClass("jqInited");var opts=$.extend({},$this.metadata());$this.masonry(opts);});});})(jQuery);;
