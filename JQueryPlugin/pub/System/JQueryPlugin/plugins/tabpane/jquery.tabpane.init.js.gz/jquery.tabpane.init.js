(function($){$(function(){$(".jqTabPane").tabpane();});})(jQuery);;
