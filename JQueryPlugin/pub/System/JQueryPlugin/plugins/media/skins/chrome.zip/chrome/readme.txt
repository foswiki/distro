Author: ZeroCool.hu

Description:
To use the "Chrome" JW Player skin you just have to follow the instructions as posted here:
http://www.longtailvideo.com/addons/implementing_skins.html