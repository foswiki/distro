(function($){$(function(){$.each(foswiki.jquery.tabpane,function(){$("#"+this.id).tabpane(this);});});})(jQuery);;
