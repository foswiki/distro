;(function($){$(function(){window.setTimeout(function(){try{$('.jqFocus:first').focus();}catch(error){};},200);});})(jQuery);;
