(function($){$(function(){$(".jqCorner").not(".jqInited").addClass(".jqInited").corner();});})(jQuery);;
